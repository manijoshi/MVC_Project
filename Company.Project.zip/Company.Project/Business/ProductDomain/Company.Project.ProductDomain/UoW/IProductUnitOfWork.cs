﻿using Company.Project.Core.Data.Transaction;
using Company.Project.ProductDomain.Repository;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Company.Project.ProductDomain.UoW
{
    public interface IProductUnitOfWork:IUnitOfWork
    { 
       
    }
}

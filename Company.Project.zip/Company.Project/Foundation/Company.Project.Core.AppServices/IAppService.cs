﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Company.Project.Core.AppServices
{
    /// <summary>
    /// Defines the contract for implementing an Application Service
    /// </summary>
    public interface IAppService
    {
    }
}
